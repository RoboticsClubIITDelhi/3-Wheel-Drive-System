#include <Kangaroo.h>
#include <Encoder.h>

// === ENCODER SECTION ===
Encoder enc2(2, 3);    // Encoder 2 (local to this Mega)
long lastEnc2 = 0;

#define RC_CH2_PIN 4
#define RC_CH3_PIN 5
#define RC_CH4_PIN 6

KangarooSerial Kangaroo_2(Serial2);  // TX2/RX2
KangarooSerial Kangaroo_1(Serial1);  // TX1/RX1

KangarooChannel wheel3(Kangaroo_2, '1');  // Kangaroo 2, channel 1
KangarooChannel wheel1(Kangaroo_1, '1');  // Kangaroo 1, channel 1
KangarooChannel wheel2(Kangaroo_1, '2');  // Kangaroo 1, channel 2

unsigned long pulse_ch2, pulse_ch3, pulse_ch4;
int loop_count = 0;
float temp_vx = 0.0, temp_vy = 0.0, temp_w = 0.0;

void setup() {
  Serial.begin(9600);
  Serial1.begin(9600);
  Serial2.begin(9600);
  Serial3.begin(9600);  // === ENCODER SECTION: Send to Odometry Mega ===

  pinMode(RC_CH4_PIN, INPUT);
  pinMode(RC_CH2_PIN, INPUT);
  pinMode(RC_CH3_PIN, INPUT);

  wheel1.start();
  wheel1.home().wait();
  wheel2.start();
  wheel2.home().wait();
  wheel3.start();
  wheel3.home().wait();

  Serial.println("RC 3-Channel Verification Started (Mega, pins 4, 5, 6)");
  Serial.println("All good to go");
}

void loop() {
  // === ENCODER SECTION ===
  long currentEnc2 = enc2.read();
  if (currentEnc2 != lastEnc2) {
    Serial3.println(currentEnc2);   // Send encoder value to odometry Mega
    Serial.print("ENC2 → Sent: ");
    Serial.println(currentEnc2);
    lastEnc2 = currentEnc2;
  }

  // === RC Channel Input ===
  pulse_ch4 = pulseIn(RC_CH4_PIN, HIGH, 30000);
  pulse_ch2 = pulseIn(RC_CH2_PIN, HIGH, 30000);
  pulse_ch3 = pulseIn(RC_CH3_PIN, HIGH, 30000);

  float vx = 0.0, vy = 0.0, w = 0.0;
  if (pulse_ch4 >= 950 && pulse_ch4 <= 2000) vx = (pulse_ch4 - 1500.0)/500.0;
  if (pulse_ch2 >= 950 && pulse_ch2 <= 2000) w  = (pulse_ch2 - 1500.0)/500.0;
  if (pulse_ch3 >= 950 && pulse_ch3 <= 2000) vy = (pulse_ch3 - 1500.0)/500.0;

  if (loop_count != 0) {
    vx = EaseIn(vx, temp_vx, 0.5);
    vy = EaseIn(vy, temp_vy, 0.5);
    w  = EaseIn(w,  temp_w,  0.5);
  }

  Serial.print("CH2: "); Serial.print(pulse_ch2); Serial.print("μs ("); Serial.print(w); Serial.print(") | ");
  Serial.print("CH3: "); Serial.print(pulse_ch3); Serial.print("μs ("); Serial.print(vy); Serial.print(") | ");
  Serial.print("CH4: "); Serial.print(pulse_ch4); Serial.print("μs ("); Serial.print(vx); Serial.println(")");

  bool constraint_var = false;
  if (abs(vx) < 0.1) { vx = 0; constraint_var = true; Serial.println("Movement in x-direction is restricted |"); }
  if (abs(vy) < 0.1) { vy = 0; constraint_var = true; Serial.println("Movement in y-direction is restricted |"); }
  if (abs(w)  < 0.1) {  w = 0; constraint_var = true; Serial.println("Rotation is restricted |"); }

  float pivot_speed_index = 0.15;
  float max_speed_index = 100;

  float w1 = max_speed_index * (( 0.5 * vx) - (0.867 * vy) - (pivot_speed_index * w));
  float w2 = max_speed_index * ((-0.5 * vx) - (0.867 * vy) + (pivot_speed_index * w));
  float w3 = max_speed_index * (vx + (pivot_speed_index * w));

  wheel1.s(w1);
  wheel2.s(w2);
  wheel3.s(w3);

  if (constraint_var) {
    Serial.println("Robot under motion with constraints displayed above");
  } else {
    Serial.println("Robot under arbitrary motion");
  }

  delay(200);

  Serial.print("Variable_1:"); Serial.print(vx);
  Serial.print(", Variable_2:"); Serial.print(vy);
  Serial.print(", Variable_3:"); Serial.println(w);
  Serial.println(lastEnc2);

  loop_count++;
  temp_vx = vx;
  temp_vy = vy;
  temp_w  = w;
}

float EaseIn(float prev_value, float curr_value, float smooth_index) {
  float diff = curr_value - prev_value;
  float x = abs(diff);
  float step = smooth_index * x * x;
  return (diff >= 0) ? (prev_value + step) : (prev_value - step);
}
