#include <Encoder.h>

Encoder enc3(20, 21);   // Mega encoder 2

const float wheelRadius = 5.0;
const float robotRadius = 25.0;
const int ticksPerRevolution = 2400;
const float pi = 3.14159265;
const float ticksToRadians = 2 * pi / ticksPerRevolution;

float globalX = 0, globalY = 0, globalTheta = 0;
long ENC1_tempTickCount = 0, ENC2_tempTickCount = 0, ENC3_tempTickCount = 0;

#define NANO_RESET_PIN 7
#define UNO_RESET_PIN 6
String nanoBuffer = "";
String unoBuffer = "";

void setup() {
  Serial.begin(9600);      // Serial monitor output
  Serial1.begin(9600);     // Reading ENC1 from Nano Every
  Serial2.begin(9600);

  pinMode(NANO_RESET_PIN, OUTPUT);
  pinMode(UNO_RESET_PIN, OUTPUT);
  digitalWrite(NANO_RESET_PIN, LOW);
  digitalWrite(UNO_RESET_PIN, LOW);
  delay(100);                      // Reset Nano Every
  digitalWrite(NANO_RESET_PIN, HIGH);
  digitalWrite(UNO_RESET_PIN, HIGH);

  Serial.println("|  ORIGIN REGISTERED  |");
}

void loop() {
  // --- Read Nano's encoder value from Serial1 (ENC1) ---
  while (Serial1.available()) {
    char c = Serial1.read();
    if (c == '\n') {
      ENC1_tempTickCount = nanoBuffer.toInt();
      nanoBuffer = "";
    } else {
      nanoBuffer += c;
    }
  }

  while (Serial2.available()) {
  char d = Serial2.read();
  if (d == '\n') {
    ENC2_tempTickCount = unoBuffer.toInt();  // <-- CORRECT VARIABLE
    unoBuffer = "";
  } else {
    unoBuffer += d;
  }
}


  // --- Read local encoders ---
  long enc3_now = enc3.read();

  // Compute deltas
  static long last_enc1 = ENC1_tempTickCount;
  long delta1 = ENC1_tempTickCount - last_enc1;
  last_enc1 = ENC1_tempTickCount;

  static long last_enc2 = ENC2_tempTickCount;
  long delta2 = ENC2_tempTickCount - last_enc2;
  last_enc2 = ENC2_tempTickCount;

  long delta3 = enc3_now - ENC3_tempTickCount;

  ENC3_tempTickCount += delta3;

  // Compute wheel rotations
  float phi1 = delta1 * ticksToRadians;
  float phi2 = delta2 * ticksToRadians;
  float phi3 = delta3 * ticksToRadians;

  // Kinematic model
  float dx = wheelRadius * ((2.0 / 3.0) * phi1 - (1.0 / 3.0) * phi2 - (1.0 / 3.0) * phi3);
  float dy = wheelRadius * ((1.0 / sqrt(3.0)) * phi2 - (1.0 / sqrt(3.0)) * phi3);
  float dtheta = (wheelRadius / (3.0 * robotRadius)) * (phi1 + phi2 + phi3);

  globalX += dx * cos(globalTheta) - dy * sin(globalTheta);
  globalY += dx * sin(globalTheta) + dy * cos(globalTheta);
  globalTheta += dtheta;

  // Output final position and encoder values
  Serial.print("X: "); Serial.print(globalX);
  Serial.print(" cm, Y: "); Serial.print(globalY);
  Serial.print(" cm, θ: "); Serial.print(globalTheta * 180 / pi);
  Serial.print(" | ENC1: "); Serial.print(ENC1_tempTickCount);
  Serial.print(" | ENC2: "); Serial.print(ENC2_tempTickCount);
  Serial.print(" | ENC3: "); Serial.println(enc3_now);

  delay(20);
}
