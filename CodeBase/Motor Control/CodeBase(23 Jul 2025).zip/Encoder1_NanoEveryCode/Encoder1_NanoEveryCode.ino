#include <Encoder.h>

Encoder enc1(10, 11);  // Connect encoder A and B to D10 and D11
long lastPos = 0;

void setup() {
  Serial.begin(9600);     // USB Serial for debugging (optional)
  Serial1.begin(9600);    // TX (D1) → Mega RX1 (pin 19)
  Serial.println("Nano Every started");
}

void loop() {
  long pos = enc1.read();

  // Send only if encoder value changes
  if (pos != lastPos) {
    Serial1.println(pos);      // Send to Mega
    Serial.print("ENC1: ");    // Optional debugging to PC
    Serial.println(pos);
    lastPos = pos;
  }

  delay(10);  // Prevent flooding
}
